// Reference class
package com.reborn.chaosrealms;

public class Reference {
    public static final String MODID = "reborn";
    public static final String NAME = "Chaos Realms";
    public static final String VERSION = "1.0";
}
