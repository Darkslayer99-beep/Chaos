// Main mod class for Chaos Realms
package com.reborn.chaosrealms;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = Reference.MODID, name = Reference.NAME, version = Reference.VERSION)
public class ChaosRealms {
    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        System.out.println("Chaos Realms is loading!");
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // Register mobs, items, dimensions here
    }
}
